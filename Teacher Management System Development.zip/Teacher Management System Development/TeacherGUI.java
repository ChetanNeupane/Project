import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;
import java.util.*;


public class TeacherGUI{
   
    ArrayList<Teacher> tlist = new ArrayList();
   

    public void lecturer()
    {
    //----------------------------------------------------------------------------------------------------        
    JFrame frame = new JFrame("Coursework GUI");// making frame to include all the necessary button,text area/feild.
    frame.getContentPane().setBackground(Color.RED);
    JPanel panel = new JPanel();
    panel.setBounds(0,0,700,600);
    panel.setLayout(null);
    panel.setBackground(new Color(173, 216, 230));

   
    Font font1 = new Font("Showcard Gothic", Font.BOLD, 20);//Adding font
    Font font2 = new Font("Arial", Font.BOLD, 8);
    font2= font2.deriveFont(font2.getSize() + 6f);
    //--------------------------------------------------------------------------
   
   
    //-------------------------------------------------------------------------
    JLabel jl1 = new JLabel("Lecturer");// Adding lecture and its textfeild
    jl1.setBounds(250,0,300,70);
    jl1.setFont(font1);
    //-------------------------------------------------------------------------
   
   
    //----------------------------------------------------------------------
    JLabel jl2 = new JLabel("Teacher ID :- ");// Adding lecture and its textfeild
    jl2.setBounds(20,50,100,70);
   
    JTextField jt1 = new JTextField("");
    jt1.setBounds(175,65,190,30);
   
    jl2.setFont(font2);
   
   
    //----------------------------------------------------------------------
   
    //---------------------------------------------------------------------
    JLabel jl3 = new JLabel("Teacher Name :-");// Adding lecture and its textfeild
    jl3.setBounds(20,88,125,70);
   
    JTextField jt2 = new JTextField("");
    jt2.setBounds(175,110,190,30);
   
    jl3.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jl4 = new JLabel("Address:-");// Adding lecture and its textfeild
    jl4.setBounds(20,134,110,70);
   
    JTextField jt3 = new JTextField("");
    jt3.setBounds(175,155,190,30);
   
    jl4.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jl5 = new JLabel("Working Type:-");// Adding lecture and its textfeild
    jl5.setBounds(20,180,110,70);
   
    JTextField jt4 = new JTextField("");
    jt4.setBounds(175,200,190,30);
   
    jl5.setFont(font2);
   
    //--------------------------------------------------------------------
   
    //---------------------------------------------------------------------
    JLabel jl6 = new JLabel("Employment Status:-");// Adding lecture and its textfeild
    jl6.setBounds(20,226,150,70);
   
    JTextField jt5 = new JTextField("");
    jt5.setBounds(175,245,190,30);
   
    jl6.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jl7 = new JLabel("Department:-");// Adding lecture and its textfeild
    jl7.setBounds(20,272,130,70);
   
    JTextField jt6 = new JTextField("");
    jt6.setBounds(175,290,190,30);
   
    jl7.setFont(font2);
   
    //--------------------------------------------------------------------
   
      //---------------------------------------------------------------------
    JLabel jl8 = new JLabel("Graded Score:-");// Adding lecture and its textfeild
    jl8.setBounds(20,318,130,70);
   
    JTextField jt7 = new JTextField("");
    jt7.setBounds(175,338,190,30);
   
    jl8.setFont(font2);
   
    //--------------------------------------------------------------------
   
 
    //---------------------------------------------------------------------
    JLabel jl9 = new JLabel("Year of Experince:-");// Adding lecture and its textfeild
    jl9.setBounds(20,364,150,70);
   
    JTextField jt8 = new JTextField("");
    jt8.setBounds(175,385,190,30);
   
    jl9.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //-----------------------------------------------------------------------
    JButton b1 = new JButton("Change to tutor");// Adding lecture and its textfeild
    b1.setBounds(410,280,220,40);
    b1.setFont(font2);
    b1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    frame.dispose();
    tutor(); // Call the tutor method
    }
    });
   

    //--------------------------------------------------------------------
    JButton b2 = new JButton("Display");// Adding lecture and its textfeild
    b2.setBounds(20,450,150,40);
    b2.setFont(font2);
    b2.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
       for(Teacher t : tlist)
       {
           if(t instanceof Lecturer)
           {
               t.display();
           }
       }
    }
    });
   
    //-----------------------------------------------------------------------------------
   
   
    //--------------------------------------------------------------------
    JButton b3 = new JButton("Grade Assignment");// Adding lecture and its textfeild
    b3.setBounds(410,85,220,40);
    b3.setFont(font2);
    b3.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
 
    }
    });
   
    //-----------------------------------------------------------------------------------
   
    //------------------------------------------------------------------------------------
    JButton b4 = new JButton("Clear");// Adding lecture and its textfeild
    b4.setBounds(485,450,150,40);
    b4.setFont(font2);
    b4.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    jt1.setText("");
    jt2.setText("");
    jt3.setText("");
    jt4.setText("");
    jt5.setText("");
    jt6.setText("");
    jt7.setText("");
    jt8.setText("");
    }
    });
    //------------------------------------------------------------------------------------
   
   
   
   
    //------------------------------------------------------------------------------------
    JButton b5 = new JButton("Add Lecture");// Adding lecture and its textfeild
    b5.setBounds(410,180,220,40);
    b5.setFont(font2);
    b5.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      if (jt1.getText().isEmpty() || jt2.getText().isEmpty() || jt3.getText().isEmpty() || jt4.getText().isEmpty() || jt5.getText().isEmpty() || jt6.getText().isEmpty() || jt7.getText().isEmpty() || jt8.getText().isEmpty())
      {
          JOptionPane.showMessageDialog(null, "Fill the table");
      }
     
      Lecturer l1 = new Lecturer(Integer.parseInt(jt1.getText()),jt2.getText(),jt3.getText(),jt4.getText(),jt5.getText(),jt6.getText(),Integer.parseInt(jt7.getText()),Integer.parseInt(jt8.getText()));
      tlist.add(l1);
      JOptionPane.showMessageDialog(null, "Added to table");
       
    }
    });
    //------------------------------------------------------------------------------------
   
   
   
   
   
   
    //------------------------------------------------------------------------------------
    frame.setSize(700,600);//
    frame.setVisible(true);
    frame.setLayout(null);
    //-----------------------------------------------------------------
   
    //-----------------------------------------------------------------
    frame.add(panel);//adding panel on frame
    panel.add(jl1);
   
    panel.add(jl2);
    panel.add(jt1);
   
    panel.add(jl3);
    panel.add(jt2);
   
    panel.add(jl4);
    panel.add(jt3);
   
     
    panel.add(jl5);
    panel.add(jt4);
   
    panel.add(jl6);
    panel.add(jt5);
   
 
    panel.add(jl7);
    panel.add(jt6);
   
    panel.add(jl8);
    panel.add(jt7);
   
    panel.add(jl9);
    panel.add(jt8);
    //------------------------------------------------------------------------------------
   
    //---------------------------------------------------------------------------------------
    panel.add(b1);//adding button to the panel
    panel.add(b2);
    panel.add(b3);
    panel.add(b4);
    panel.add(b5);
    //----------------------------------------------------------------------------------
    }
   
    public void tutor(){
    JFrame frame = new JFrame("Coursework GUI");// making frame to include all the necessary button,text area/feild for Tutor GUI.
    JPanel panel = new JPanel();
    panel.setBounds(0,0,700,600);
    panel.setLayout(null);
    panel.setBackground(new Color(173, 216, 230));
   
    Font font1 = new Font("Showcard Gothic", Font.BOLD, 20);
    Font font2 = new Font("Arial", Font.BOLD, 8);
    font2= font2.deriveFont(font2.getSize() + 6f);
   
    //-------------------------------------------------------------------------
    JLabel jll1 = new JLabel("Tutor");
    jll1.setBounds(250,0,300,70);
    jll1.setFont(font1);
    //-------------------------------------------------------------------------
   
    //----------------------------------------------------------------------
    JLabel jll2 = new JLabel("Teacher ID :- ");
    jll2.setBounds(20,50,100,70);
   
    JTextField jtt1 = new JTextField("");
    jtt1.setBounds(175,65,190,30);
   
    jll2.setFont(font2);
   
   
    //----------------------------------------------------------------------
   
    //---------------------------------------------------------------------
    JLabel jll3 = new JLabel("Teacher Name :-");
    jll3.setBounds(20,88,125,70);
   
    JTextField jtt2 = new JTextField("");
    jtt2.setBounds(175,110,190,30);
   
    jll3.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jll4 = new JLabel("Working Hour:-");
    jll4.setBounds(20,134,110,70);
   
    JTextField jtt3 = new JTextField("");
    jtt3.setBounds(175,155,190,30);
   
    jll4.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jll5 = new JLabel("Working Type:-");
    jll5.setBounds(20,180,110,70);
   
    JTextField jtt4 = new JTextField("");
    jtt4.setBounds(175,200,190,30);
   
    jll5.setFont(font2);
   
    //--------------------------------------------------------------------
   
    //---------------------------------------------------------------------
    JLabel jll6 = new JLabel("Employment Status:-");
    jll6.setBounds(20,226,150,70);
   
    JTextField jtt5 = new JTextField("");
    jtt5.setBounds(175,245,190,30);
   
    jll6.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jll7 = new JLabel("Salary:-");
    jll7.setBounds(20,272,130,70);
   
    JTextField jtt6 = new JTextField("");
    jtt6.setBounds(175,290,190,30);
   
    jll7.setFont(font2);
   
    //--------------------------------------------------------------------
   
      //---------------------------------------------------------------------
    JLabel jll8 = new JLabel("Specialization:-");
    jll8.setBounds(20,318,160,70);
   
    JTextField jtt7 = new JTextField("");
    jtt7.setBounds(175,338,190,30);
   
    jll8.setFont(font2);
   
    //--------------------------------------------------------------------
   
 
    //---------------------------------------------------------------------
    JLabel jll9 = new JLabel("Qualification:-");
    jll9.setBounds(20,364,180,70);
   
    JTextField jtt8 = new JTextField("");
    jtt8.setBounds(175,385,190,30);
   
    jll9.setFont(font2);
   
    //--------------------------------------------------------------------
   
   
    //---------------------------------------------------------------------
    JLabel jll10 = new JLabel("Performance Index:-");
    jll10.setBounds(20,410,180,70);
   
    JTextField jtt9 = new JTextField("");
    jtt9.setBounds(175,429,190,30);
   
    jll10.setFont(font2);
   
    //--------------------------------------------------------------------
   
   

    JButton bb1 = new JButton("Clear");
    bb1.setBounds(20,500,150,40);
    bb1.setFont(font2);
    bb1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    jtt1.setText("");
    jtt2.setText("");
    jtt3.setText("");
    jtt4.setText("");
    jtt5.setText("");
    jtt6.setText("");
    jtt7.setText("");
    jtt8.setText("");
    jtt9.setText("");
    }
    });
   

     
    JButton bb3 = new JButton("Display");
    bb3.setBounds(485,500,150,40);
    bb3.setFont(font2);
    bb3.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
       
    }
   
    });  
   
    JButton bb4 = new JButton("Set Salary");
    bb4.setBounds(410,100,220,40);
    bb4.setFont(font2);
    bb4.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    }
    });
   
    JButton bb5 = new JButton("Add Tutor");
    bb5.setBounds(410,180,220,40);
    bb5.setFont(font2);
    bb5.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    }
    });
   
    JButton bb6 = new JButton("Remove Tutor");
    bb6.setBounds(410,270,220,40);
    bb6.setFont(font2);
    bb6.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    }
    });
   
    JButton bb2 = new JButton("Change to Lecturer");
    bb2.setBounds(410,358,220,40);
    bb2.setFont(font2);
    bb2.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
    frame.dispose();
    lecturer(); // Call the tutor method
    }
    });
   
   
    //------------------------------------------------------------------------------------
    frame.setSize(700,630);
    frame.setVisible(true);
    frame.setLayout(null);
    //-----------------------------------------------------------------
   
    //-----------------------------------------------------------------
    frame.add(panel);//adding panel on frame
    panel.add(jll1);
   
    panel.add(jll2);
    panel.add(jtt1);
   
    panel.add(jll3);
    panel.add(jtt2);
   
    panel.add(jll4);
    panel.add(jtt3);
   
     
    panel.add(jll5);
    panel.add(jtt4);
   
    panel.add(jll6);
    panel.add(jtt5);
   
 
    panel.add(jll7);
    panel.add(jtt6);
   
    panel.add(jll8);
    panel.add(jtt7);
   
    panel.add(jll9);
    panel.add(jtt8);
   
    panel.add(jll10);
    panel.add(jtt9);
   
    panel.add(bb1);
    panel.add(bb2);
    panel.add(bb3);
    panel.add(bb4);
    panel.add(bb5);
    panel.add(bb6);
    }
   
    public static void main(String[] args)
    {
        TeacherGUI gui = new TeacherGUI();
        gui.lecturer();
    }
     
}
